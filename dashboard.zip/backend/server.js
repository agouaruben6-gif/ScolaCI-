require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const errorHandler = require('./src/middleware/errorHandler');

// Initialisation de l'application
const app = express();

// Middleware
app.use(helmet()); // Sécurité
app.use(cors()); // Autoriser les requêtes cross-origin
app.use(express.json()); // Parser le JSON
app.use(express.urlencoded({ extended: true }));
app.use(morgan('dev')); // Logging

// Route de test
app.get('/', (req, res) => {
  res.json({ success: true, message: 'Bienvenue sur l\'API ScolaCI', data: {} });
});

// Importation des routes
app.use('/api/auth', require('./src/routes/auth.routes'));
app.use('/api/admin', require('./src/routes/admin.routes'));
app.use('/api/students', require('./src/routes/student.routes'));
app.use('/api/teachers', require('./src/routes/teacher.routes'));
app.use('/api/schedules', require('./src/routes/schedule.routes'));
app.use('/api/attendance', require('./src/routes/attendance.routes'));
app.use('/api/grades', require('./src/routes/grade.routes'));
app.use('/api/notifications', require('./src/routes/notification.routes'));
app.use('/api/announcements', require('./src/routes/announcement.routes'));

// Gestion globale des erreurs
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Serveur en cours d'exécution sur le port ${PORT}`);
});
