# ScolaCI Backend

Backend Node.js pour l'application de gestion scolaire ScolaCI.

## Structure du projet

- `src/` : Code source (contrôleurs, modèles, routes, middleware, utils)
- `db/` : Scripts de base de données (migrations, seeds)

## Installation

1. Installer les dépendances :
   ```bash
   npm install
   ```
2. Configurer la base de données PostgreSQL avec les identifiants locaux.
3. Copier `.env.example` en `.env` et ajuster les variables.
4. Exécuter les migrations SQL dans `db/migrations/` et (optionnellement) le seed dans `db/seed.sql`.
5. Lancer le serveur :
   ```bash
   npm run dev
   ```

## Technologies utilisées
- Express.js
- PostgreSQL (via le module `pg`)
- JWT pour l'authentification
- bcryptjs pour le hachage des mots de passe
