-- Seed file pour Côte d'Ivoire
INSERT INTO users (email, password_hash, role, first_name, last_name, phone) VALUES 
('admin@scolaci.ci', '$2a$10$YourHashedPasswordHere', 'admin', 'Kouadio', 'Jean', '0102030405'),
('prof.koffi@scolaci.ci', '$2a$10$YourHashedPasswordHere', 'teacher', 'Koffi', 'Awa', '0506070809'),
('eleve.yao@scolaci.ci', '$2a$10$YourHashedPasswordHere', 'student', 'Yao', 'Marc', '0708091011');

INSERT INTO schools (name, type, address, city, admin_id, evaluation_system) VALUES 
('Lycée Classique d''Abidjan', 'lycee_general', 'Cocody', 'Abidjan', 1, 'trimestre');

INSERT INTO classes (school_id, name, level, section, academic_year, capacity) VALUES 
(1, 'Terminale C1', 'terminale', 'C', '2023-2024', 50);

-- Insérer les autres données de test ici
