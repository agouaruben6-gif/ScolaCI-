CREATE TABLE IF NOT EXISTS teachers (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    school_id INTEGER REFERENCES schools(id) ON DELETE CASCADE,
    employee_number VARCHAR(50) UNIQUE NOT NULL,
    specialization VARCHAR(100),
    hire_date DATE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Ajouter la clé étrangère pour subjects maintenant que teachers existe
ALTER TABLE subjects
ADD CONSTRAINT fk_subjects_teacher
FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE SET NULL;
