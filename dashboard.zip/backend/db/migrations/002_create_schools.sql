CREATE TABLE IF NOT EXISTS schools (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(50) CHECK (type IN ('primaire', 'college', 'lycee_general', 'lycee_technique', 'universite', 'grande_ecole')) NOT NULL,
    address TEXT,
    city VARCHAR(100),
    country VARCHAR(100) DEFAULT 'CI',
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    phone VARCHAR(20),
    email VARCHAR(255),
    logo_url VARCHAR(255),
    admin_id INTEGER REFERENCES users(id),
    evaluation_system VARCHAR(50) CHECK (evaluation_system IN ('trimestre', 'semestre')) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    subscription_plan VARCHAR(50) CHECK (subscription_plan IN ('basique', 'pro', 'universite')) DEFAULT 'basique',
    subscription_expires_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
