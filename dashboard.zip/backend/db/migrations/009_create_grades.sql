CREATE TABLE IF NOT EXISTS grades (
    id SERIAL PRIMARY KEY,
    student_id INTEGER REFERENCES students(id) ON DELETE CASCADE,
    subject_id INTEGER REFERENCES subjects(id) ON DELETE CASCADE,
    school_id INTEGER REFERENCES schools(id) ON DELETE CASCADE,
    grade_value DECIMAL(5, 2) NOT NULL,
    max_grade DECIMAL(5, 2) DEFAULT 20.0,
    grade_type VARCHAR(50) CHECK (grade_type IN ('devoir', 'composition', 'examen', 'tp', 'oral')) NOT NULL,
    period VARCHAR(50) NOT NULL, -- trimestre1/semestre1
    academic_year VARCHAR(20) NOT NULL,
    recorded_by INTEGER REFERENCES teachers(id) ON DELETE SET NULL,
    submitted_to_admin BOOLEAN DEFAULT FALSE,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS averages (
    id SERIAL PRIMARY KEY,
    student_id INTEGER REFERENCES students(id) ON DELETE CASCADE,
    subject_id INTEGER REFERENCES subjects(id) ON DELETE CASCADE,
    school_id INTEGER REFERENCES schools(id) ON DELETE CASCADE,
    period VARCHAR(50) NOT NULL,
    academic_year VARCHAR(20) NOT NULL,
    average_value DECIMAL(5, 2) NOT NULL,
    coefficient DECIMAL(4, 2) DEFAULT 1.0,
    rank_in_class INTEGER,
    total_students INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS general_averages (
    id SERIAL PRIMARY KEY,
    student_id INTEGER REFERENCES students(id) ON DELETE CASCADE,
    school_id INTEGER REFERENCES schools(id) ON DELETE CASCADE,
    period VARCHAR(50) NOT NULL,
    academic_year VARCHAR(20) NOT NULL,
    general_average DECIMAL(5, 2) NOT NULL,
    rank_in_class INTEGER,
    total_students INTEGER,
    decision VARCHAR(50) CHECK (decision IN ('admis', 'rattrapage', 'redoublant', 'felicitations', 'encouragements', 'tableauhonneur')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
