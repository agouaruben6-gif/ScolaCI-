const express = require('express');
const router = express.Router();
const teacherController = require('../controllers/teacher.controller');
const { verifyToken } = require('../middleware/auth');
const { isTeacher } = require('../middleware/roleCheck');

router.use(verifyToken, isTeacher);

router.get('/profile', teacherController.getProfile);
router.get('/schedule', teacherController.getSchedule);

module.exports = router;
