const express = require('express');
const router = express.Router();
const announcementController = require('../controllers/announcement.controller');
const { verifyToken } = require('../middleware/auth');
const { isAdmin } = require('../middleware/roleCheck');

router.use(verifyToken);

router.get('/', announcementController.getAnnouncements);
router.post('/', isAdmin, announcementController.createAnnouncement);

module.exports = router;
