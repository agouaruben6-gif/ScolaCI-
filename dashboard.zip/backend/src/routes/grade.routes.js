const express = require('express');
const router = express.Router();
const gradeController = require('../controllers/grade.controller');
const { verifyToken } = require('../middleware/auth');
const { isTeacher } = require('../middleware/roleCheck');

router.use(verifyToken, isTeacher);

router.post('/', gradeController.addGrade);
router.get('/:classId/:subjectId', gradeController.getGrades);
router.post('/submit', gradeController.submitGrades);

module.exports = router;
