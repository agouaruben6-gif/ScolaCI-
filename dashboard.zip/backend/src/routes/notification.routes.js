const express = require('express');
const router = express.Router();
const notificationController = require('../controllers/notification.controller');
const { verifyToken } = require('../middleware/auth');
const { isAdmin } = require('../middleware/roleCheck');

router.use(verifyToken);

router.get('/', notificationController.getNotifications);
router.post('/send', isAdmin, notificationController.sendNotification);

module.exports = router;
