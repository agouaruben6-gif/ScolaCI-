const express = require('express');
const router = express.Router();
const adminController = require('../controllers/admin.controller');
const { verifyToken } = require('../middleware/auth');
const { isAdmin } = require('../middleware/roleCheck');

router.use(verifyToken, isAdmin);

router.post('/students', adminController.createStudent);
router.get('/students', adminController.getStudents);

router.post('/teachers', adminController.createTeacher);

router.post('/classes', adminController.createClass);
router.get('/classes', adminController.getClasses);

router.post('/subjects', adminController.createSubject);

module.exports = router;
