const express = require('express');
const router = express.Router();
const scheduleController = require('../controllers/schedule.controller');
const { verifyToken } = require('../middleware/auth');
const { isAdmin } = require('../middleware/roleCheck');

router.use(verifyToken);

router.post('/', isAdmin, scheduleController.createSchedule);
router.get('/class/:classId', scheduleController.getByClass);

module.exports = router;
