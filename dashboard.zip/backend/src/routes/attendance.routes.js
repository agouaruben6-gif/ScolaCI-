const express = require('express');
const router = express.Router();
const attendanceController = require('../controllers/attendance.controller');
const { verifyToken } = require('../middleware/auth');
const { isTeacher } = require('../middleware/roleCheck');

router.use(verifyToken);

router.post('/', isTeacher, attendanceController.record);
router.get('/:classId/:date', isTeacher, attendanceController.getByClassAndDate);

module.exports = router;
