const express = require('express');
const router = express.Router();
const studentController = require('../controllers/student.controller');
const { verifyToken } = require('../middleware/auth');
const { isStudent } = require('../middleware/roleCheck');

router.use(verifyToken, isStudent);

router.get('/profile', studentController.getProfile);
router.get('/schedule', studentController.getSchedule);

module.exports = router;
