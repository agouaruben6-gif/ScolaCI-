const { errorResponse } = require('../utils/response');

const isRole = (roles) => {
  return (req, res, next) => {
    if (!req.user || !req.user.role) {
      return errorResponse(res, 401, 'Non autorisé. Rôle manquant.');
    }

    if (roles.includes(req.user.role)) {
      return next();
    }

    return errorResponse(res, 403, 'Accès refusé. Vous n\'avez pas les permissions nécessaires.');
  };
};

module.exports = {
  isAdmin: isRole(['admin']),
  isTeacher: isRole(['teacher', 'admin']),
  isStudent: isRole(['student', 'admin']),
  hasAnyRole: isRole
};
