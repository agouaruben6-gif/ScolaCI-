const jwt = require('jsonwebtoken');
const jwtConfig = require('../config/jwt');
const { errorResponse } = require('../utils/response');

const verifyToken = (req, res, next) => {
  const token = req.headers['authorization']?.split(' ')[1];

  if (!token) {
    return errorResponse(res, 403, 'Un token est requis pour l\'authentification');
  }

  try {
    const decoded = jwt.verify(token, jwtConfig.secret);
    req.user = decoded;
  } catch (err) {
    return errorResponse(res, 401, 'Token invalide', err.message);
  }
  return next();
};

module.exports = {
  verifyToken
};
