const { errorResponse } = require('../utils/response');

const errorHandler = (err, req, res, next) => {
  console.error(err.stack);
  
  // Si c'est une erreur de la base de données (pg)
  if (err.code) {
    // Par exemple, violation de contrainte unique
    if (err.code === '23505') {
      return errorResponse(res, 409, 'Cette ressource existe déjà', err.detail);
    }
  }

  errorResponse(res, 500, 'Erreur interne du serveur', process.env.NODE_ENV === 'development' ? err.message : undefined);
};

module.exports = errorHandler;
