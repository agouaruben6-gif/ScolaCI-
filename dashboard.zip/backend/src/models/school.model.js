const db = require('../config/database');

class SchoolModel {
  static async create(schoolData) {
    const { name, type, address, city, admin_id, evaluation_system } = schoolData;
    const query = `
      INSERT INTO schools (name, type, address, city, admin_id, evaluation_system)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING *
    `;
    const values = [name, type, address, city, admin_id, evaluation_system];
    const { rows } = await db.query(query, values);
    return rows[0];
  }

  static async findByAdminId(adminId) {
    const query = 'SELECT * FROM schools WHERE admin_id = $1';
    const { rows } = await db.query(query, [adminId]);
    return rows[0];
  }

  static async update(id, schoolData) {
    const { name, address, city, phone, email } = schoolData;
    const query = `
      UPDATE schools
      SET name = COALESCE($1, name),
          address = COALESCE($2, address),
          city = COALESCE($3, city),
          phone = COALESCE($4, phone),
          email = COALESCE($5, email)
      WHERE id = $6
      RETURNING *
    `;
    const values = [name, address, city, phone, email, id];
    const { rows } = await db.query(query, values);
    return rows[0];
  }
}

module.exports = SchoolModel;
