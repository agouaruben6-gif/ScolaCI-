const db = require('../config/database');

class GradeModel {
  static async create(gradeData) {
    const { student_id, subject_id, school_id, grade_value, max_grade, grade_type, period, academic_year, recorded_by, notes } = gradeData;
    const query = `
      INSERT INTO grades (student_id, subject_id, school_id, grade_value, max_grade, grade_type, period, academic_year, recorded_by, notes)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      RETURNING *
    `;
    const values = [student_id, subject_id, school_id, grade_value, max_grade, grade_type, period, academic_year, recorded_by, notes];
    const { rows } = await db.query(query, values);
    return rows[0];
  }

  static async findByStudentAndSubject(studentId, subjectId) {
    const query = 'SELECT * FROM grades WHERE student_id = $1 AND subject_id = $2 ORDER BY created_at DESC';
    const { rows } = await db.query(query, [studentId, subjectId]);
    return rows;
  }

  static async findByTeacherClassSubject(teacherId, classId, subjectId) {
    const query = `
      SELECT g.*, u.first_name, u.last_name, st.student_number
      FROM grades g
      JOIN students st ON g.student_id = st.id
      JOIN users u ON st.user_id = u.id
      WHERE g.recorded_by = $1 AND st.class_id = $2 AND g.subject_id = $3
    `;
    const { rows } = await db.query(query, [teacherId, classId, subjectId]);
    return rows;
  }

  static async update(id, data) {
    const { grade_value, notes } = data;
    const query = `
      UPDATE grades
      SET grade_value = COALESCE($1, grade_value),
          notes = COALESCE($2, notes)
      WHERE id = $3
      RETURNING *
    `;
    const { rows } = await db.query(query, [grade_value, notes, id]);
    return rows[0];
  }

  static async submitGrades(classId, subjectId, teacherId, period) {
    const query = `
      UPDATE grades g
      SET submitted_to_admin = TRUE
      FROM students st
      WHERE g.student_id = st.id AND st.class_id = $1 AND g.subject_id = $2 AND g.recorded_by = $3 AND g.period = $4
      RETURNING g.id
    `;
    const { rows } = await db.query(query, [classId, subjectId, teacherId, period]);
    return rows;
  }
}

module.exports = GradeModel;
