const db = require('../config/database');

class ScheduleModel {
  static async create(scheduleData) {
    const { school_id, class_id, subject_id, teacher_id, day_of_week, start_time, end_time, room } = scheduleData;
    const query = `
      INSERT INTO schedules (school_id, class_id, subject_id, teacher_id, day_of_week, start_time, end_time, room)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING *
    `;
    const values = [school_id, class_id, subject_id, teacher_id, day_of_week, start_time, end_time, room];
    const { rows } = await db.query(query, values);
    return rows[0];
  }

  static async findByClass(classId) {
    const query = `
      SELECT sch.*, sub.name as subject_name, u.first_name, u.last_name
      FROM schedules sch
      JOIN subjects sub ON sch.subject_id = sub.id
      JOIN teachers t ON sch.teacher_id = t.id
      JOIN users u ON t.user_id = u.id
      WHERE sch.class_id = $1
      ORDER BY sch.day_of_week, sch.start_time
    `;
    const { rows } = await db.query(query, [classId]);
    return rows;
  }

  static async findByTeacher(teacherId) {
    const query = `
      SELECT sch.*, sub.name as subject_name, c.name as class_name
      FROM schedules sch
      JOIN subjects sub ON sch.subject_id = sub.id
      JOIN classes c ON sch.class_id = c.id
      WHERE sch.teacher_id = $1
      ORDER BY sch.day_of_week, sch.start_time
    `;
    const { rows } = await db.query(query, [teacherId]);
    return rows;
  }

  static async update(id, data) {
    const { day_of_week, start_time, end_time, room } = data;
    const query = `
      UPDATE schedules
      SET day_of_week = COALESCE($1, day_of_week),
          start_time = COALESCE($2, start_time),
          end_time = COALESCE($3, end_time),
          room = COALESCE($4, room)
      WHERE id = $5
      RETURNING *
    `;
    const { rows } = await db.query(query, [day_of_week, start_time, end_time, room, id]);
    return rows[0];
  }

  static async delete(id) {
    const query = 'DELETE FROM schedules WHERE id = $1 RETURNING *';
    const { rows } = await db.query(query, [id]);
    return rows[0];
  }
}

module.exports = ScheduleModel;
