const db = require('../config/database');

class NotificationModel {
  static async create(notificationData) {
    const { recipient_id, title, body, type, data } = notificationData;
    const query = `
      INSERT INTO notifications (recipient_id, title, body, type, data)
      VALUES ($1, $2, $3, $4, $5)
      RETURNING *
    `;
    const values = [recipient_id, title, body, type, data];
    const { rows } = await db.query(query, values);
    return rows[0];
  }

  static async findByUser(userId) {
    const query = 'SELECT * FROM notifications WHERE recipient_id = $1 ORDER BY created_at DESC';
    const { rows } = await db.query(query, [userId]);
    return rows;
  }

  static async markAsRead(id) {
    const query = 'UPDATE notifications SET is_read = TRUE WHERE id = $1 RETURNING *';
    const { rows } = await db.query(query, [id]);
    return rows[0];
  }

  static async markAllAsRead(userId) {
    const query = 'UPDATE notifications SET is_read = TRUE WHERE recipient_id = $1';
    await db.query(query, [userId]);
  }
}

module.exports = NotificationModel;
