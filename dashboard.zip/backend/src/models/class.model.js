const db = require('../config/database');

class ClassModel {
  static async create(classData) {
    const { school_id, name, level, section, academic_year, capacity } = classData;
    const query = `
      INSERT INTO classes (school_id, name, level, section, academic_year, capacity)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING *
    `;
    const values = [school_id, name, level, section, academic_year, capacity];
    const { rows } = await db.query(query, values);
    return rows[0];
  }

  static async findBySchool(schoolId) {
    const query = 'SELECT * FROM classes WHERE school_id = $1 ORDER BY level, name';
    const { rows } = await db.query(query, [schoolId]);
    return rows;
  }

  static async update(id, data) {
    const { name, level, section, capacity } = data;
    const query = `
      UPDATE classes
      SET name = COALESCE($1, name),
          level = COALESCE($2, level),
          section = COALESCE($3, section),
          capacity = COALESCE($4, capacity)
      WHERE id = $5
      RETURNING *
    `;
    const { rows } = await db.query(query, [name, level, section, capacity, id]);
    return rows[0];
  }

  static async delete(id) {
    const query = 'DELETE FROM classes WHERE id = $1 RETURNING *';
    const { rows } = await db.query(query, [id]);
    return rows[0];
  }
}

module.exports = ClassModel;
