const db = require('../config/database');

class StudentModel {
  static async create(studentData) {
    const { user_id, school_id, class_id, student_number, date_of_birth, guardian_name, guardian_phone, academic_year } = studentData;
    const query = `
      INSERT INTO students (user_id, school_id, class_id, student_number, date_of_birth, guardian_name, guardian_phone, academic_year, enrollment_date)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, CURRENT_DATE)
      RETURNING *
    `;
    const values = [user_id, school_id, class_id, student_number, date_of_birth, guardian_name, guardian_phone, academic_year];
    const { rows } = await db.query(query, values);
    return rows[0];
  }

  static async findBySchool(schoolId) {
    const query = `
      SELECT s.*, u.first_name, u.last_name, u.email, c.name as class_name 
      FROM students s
      JOIN users u ON s.user_id = u.id
      LEFT JOIN classes c ON s.class_id = c.id
      WHERE s.school_id = $1
    `;
    const { rows } = await db.query(query, [schoolId]);
    return rows;
  }

  static async findByUserId(userId) {
    const query = `
      SELECT s.*, u.first_name, u.last_name, u.email, c.name as class_name, sch.name as school_name
      FROM students s
      JOIN users u ON s.user_id = u.id
      LEFT JOIN classes c ON s.class_id = c.id
      JOIN schools sch ON s.school_id = sch.id
      WHERE s.user_id = $1
    `;
    const { rows } = await db.query(query, [userId]);
    return rows[0];
  }

  static async update(id, data) {
    const { class_id, guardian_name, guardian_phone } = data;
    const query = `
      UPDATE students
      SET class_id = COALESCE($1, class_id),
          guardian_name = COALESCE($2, guardian_name),
          guardian_phone = COALESCE($3, guardian_phone)
      WHERE id = $4
      RETURNING *
    `;
    const { rows } = await db.query(query, [class_id, guardian_name, guardian_phone, id]);
    return rows[0];
  }

  static async delete(id) {
    const query = 'DELETE FROM students WHERE id = $1 RETURNING user_id';
    const { rows } = await db.query(query, [id]);
    return rows[0];
  }
}

module.exports = StudentModel;
