const db = require('../config/database');

class UserModel {
  static async findByEmail(email) {
    const query = 'SELECT * FROM users WHERE email = $1 AND is_active = true';
    const { rows } = await db.query(query, [email]);
    return rows[0];
  }

  static async findById(id) {
    const query = 'SELECT * FROM users WHERE id = $1';
    const { rows } = await db.query(query, [id]);
    return rows[0];
  }

  static async create(userData) {
    const { email, password_hash, role, first_name, last_name, phone } = userData;
    const query = `
      INSERT INTO users (email, password_hash, role, first_name, last_name, phone)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING id, email, role, first_name, last_name, phone
    `;
    const values = [email, password_hash, role, first_name, last_name, phone];
    const { rows } = await db.query(query, values);
    return rows[0];
  }

  static async updateFcmToken(id, fcm_token) {
    const query = 'UPDATE users SET fcm_token = $1 WHERE id = $2 RETURNING id';
    await db.query(query, [fcm_token, id]);
  }
}

module.exports = UserModel;
