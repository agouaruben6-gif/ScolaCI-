const db = require('../config/database');

class TeacherModel {
  static async create(teacherData) {
    const { user_id, school_id, employee_number, specialization } = teacherData;
    const query = `
      INSERT INTO teachers (user_id, school_id, employee_number, specialization, hire_date)
      VALUES ($1, $2, $3, $4, CURRENT_DATE)
      RETURNING *
    `;
    const values = [user_id, school_id, employee_number, specialization];
    const { rows } = await db.query(query, values);
    return rows[0];
  }

  static async findBySchool(schoolId) {
    const query = `
      SELECT t.*, u.first_name, u.last_name, u.email, u.phone
      FROM teachers t
      JOIN users u ON t.user_id = u.id
      WHERE t.school_id = $1
    `;
    const { rows } = await db.query(query, [schoolId]);
    return rows;
  }

  static async findByUserId(userId) {
    const query = `
      SELECT t.*, u.first_name, u.last_name, u.email, sch.name as school_name
      FROM teachers t
      JOIN users u ON t.user_id = u.id
      JOIN schools sch ON t.school_id = sch.id
      WHERE t.user_id = $1
    `;
    const { rows } = await db.query(query, [userId]);
    return rows[0];
  }

  static async update(id, data) {
    const { specialization } = data;
    const query = `
      UPDATE teachers
      SET specialization = COALESCE($1, specialization)
      WHERE id = $2
      RETURNING *
    `;
    const { rows } = await db.query(query, [specialization, id]);
    return rows[0];
  }

  static async delete(id) {
    const query = 'DELETE FROM teachers WHERE id = $1 RETURNING user_id';
    const { rows } = await db.query(query, [id]);
    return rows[0];
  }
}

module.exports = TeacherModel;
