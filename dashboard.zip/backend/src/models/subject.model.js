const db = require('../config/database');

class SubjectModel {
  static async create(subjectData) {
    const { school_id, name, code, coefficient, teacher_id, class_id } = subjectData;
    const query = `
      INSERT INTO subjects (school_id, name, code, coefficient, teacher_id, class_id)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING *
    `;
    const values = [school_id, name, code, coefficient, teacher_id, class_id];
    const { rows } = await db.query(query, values);
    return rows[0];
  }

  static async findBySchool(schoolId) {
    const query = `
      SELECT s.*, c.name as class_name, u.first_name as teacher_first_name, u.last_name as teacher_last_name
      FROM subjects s
      LEFT JOIN classes c ON s.class_id = c.id
      LEFT JOIN teachers t ON s.teacher_id = t.id
      LEFT JOIN users u ON t.user_id = u.id
      WHERE s.school_id = $1
    `;
    const { rows } = await db.query(query, [schoolId]);
    return rows;
  }

  static async findByClass(classId) {
    const query = 'SELECT * FROM subjects WHERE class_id = $1';
    const { rows } = await db.query(query, [classId]);
    return rows;
  }

  static async update(id, data) {
    const { name, code, coefficient, teacher_id } = data;
    const query = `
      UPDATE subjects
      SET name = COALESCE($1, name),
          code = COALESCE($2, code),
          coefficient = COALESCE($3, coefficient),
          teacher_id = COALESCE($4, teacher_id)
      WHERE id = $5
      RETURNING *
    `;
    const { rows } = await db.query(query, [name, code, coefficient, teacher_id, id]);
    return rows[0];
  }

  static async delete(id) {
    const query = 'DELETE FROM subjects WHERE id = $1 RETURNING *';
    const { rows } = await db.query(query, [id]);
    return rows[0];
  }
}

module.exports = SubjectModel;
