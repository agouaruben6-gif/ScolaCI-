const db = require('../config/database');

class AnnouncementModel {
  static async create(announcementData) {
    const { school_id, author_id, title, content, target_role, is_pinned, expires_at } = announcementData;
    const query = `
      INSERT INTO announcements (school_id, author_id, title, content, target_role, is_pinned, expires_at)
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING *
    `;
    const values = [school_id, author_id, title, content, target_role, is_pinned, expires_at];
    const { rows } = await db.query(query, values);
    return rows[0];
  }

  static async findBySchoolAndRole(schoolId, role) {
    const roleFilter = role === 'admin' ? '' : `AND (target_role = 'all' OR target_role = '${role}')`;
    const query = `
      SELECT a.*, u.first_name, u.last_name
      FROM announcements a
      LEFT JOIN users u ON a.author_id = u.id
      WHERE a.school_id = $1 ${roleFilter}
      ORDER BY a.is_pinned DESC, a.created_at DESC
    `;
    const { rows } = await db.query(query, [schoolId]);
    return rows;
  }

  static async update(id, data) {
    const { title, content, is_pinned } = data;
    const query = `
      UPDATE announcements
      SET title = COALESCE($1, title),
          content = COALESCE($2, content),
          is_pinned = COALESCE($3, is_pinned)
      WHERE id = $4
      RETURNING *
    `;
    const { rows } = await db.query(query, [title, content, is_pinned, id]);
    return rows[0];
  }

  static async delete(id) {
    const query = 'DELETE FROM announcements WHERE id = $1 RETURNING *';
    const { rows } = await db.query(query, [id]);
    return rows[0];
  }
}

module.exports = AnnouncementModel;
