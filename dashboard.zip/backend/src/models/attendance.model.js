const db = require('../config/database');

class AttendanceModel {
  static async create(attendanceData) {
    const { student_id, subject_id, schedule_id, date, status, recorded_by, notes } = attendanceData;
    const query = `
      INSERT INTO attendance (student_id, subject_id, schedule_id, date, status, recorded_by, notes)
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING *
    `;
    const values = [student_id, subject_id, schedule_id, date, status, recorded_by, notes];
    const { rows } = await db.query(query, values);
    return rows[0];
  }

  static async findByStudent(studentId) {
    const query = `
      SELECT a.*, s.name as subject_name
      FROM attendance a
      JOIN subjects s ON a.subject_id = s.id
      WHERE a.student_id = $1
      ORDER BY a.date DESC
    `;
    const { rows } = await db.query(query, [studentId]);
    return rows;
  }

  static async findByClassAndDate(classId, date) {
    const query = `
      SELECT a.*, u.first_name, u.last_name, st.student_number
      FROM attendance a
      JOIN students st ON a.student_id = st.id
      JOIN users u ON st.user_id = u.id
      WHERE st.class_id = $1 AND a.date = $2
    `;
    const { rows } = await db.query(query, [classId, date]);
    return rows;
  }
}

module.exports = AttendanceModel;
