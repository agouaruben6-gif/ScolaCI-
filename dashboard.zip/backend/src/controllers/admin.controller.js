const StudentModel = require('../models/student.model');
const TeacherModel = require('../models/teacher.model');
const ClassModel = require('../models/class.model');
const SubjectModel = require('../models/subject.model');
const UserModel = require('../models/user.model');
const bcrypt = require('bcryptjs');
const { successResponse, errorResponse } = require('../utils/response');

// Students
exports.createStudent = async (req, res) => {
  try {
    const { email, password, first_name, last_name, school_id, class_id, student_number } = req.body;
    const password_hash = await bcrypt.hash(password, 10);
    
    const user = await UserModel.create({ email, password_hash, role: 'student', first_name, last_name });
    const student = await StudentModel.create({ ...req.body, user_id: user.id });
    
    successResponse(res, 201, 'Élève créé', { user, student });
  } catch (err) { errorResponse(res, 500, 'Erreur', err.message); }
};

exports.getStudents = async (req, res) => {
  try {
    const students = await StudentModel.findBySchool(req.query.school_id);
    successResponse(res, 200, 'Liste des élèves', students);
  } catch (err) { errorResponse(res, 500, 'Erreur', err.message); }
};

// Classes
exports.createClass = async (req, res) => {
  try {
    const classData = await ClassModel.create(req.body);
    successResponse(res, 201, 'Classe créée', classData);
  } catch (err) { errorResponse(res, 500, 'Erreur', err.message); }
};

exports.getClasses = async (req, res) => {
  try {
    const classes = await ClassModel.findBySchool(req.query.school_id);
    successResponse(res, 200, 'Classes', classes);
  } catch (err) { errorResponse(res, 500, 'Erreur', err.message); }
};

// Teachers
exports.createTeacher = async (req, res) => {
  try {
    const { email, password, first_name, last_name } = req.body;
    const password_hash = await bcrypt.hash(password, 10);
    
    const user = await UserModel.create({ email, password_hash, role: 'teacher', first_name, last_name });
    const teacher = await TeacherModel.create({ ...req.body, user_id: user.id });
    
    successResponse(res, 201, 'Professeur créé', { user, teacher });
  } catch (err) { errorResponse(res, 500, 'Erreur', err.message); }
};

// Subjects
exports.createSubject = async (req, res) => {
  try {
    const subject = await SubjectModel.create(req.body);
    successResponse(res, 201, 'Matière créée', subject);
  } catch (err) { errorResponse(res, 500, 'Erreur', err.message); }
};
