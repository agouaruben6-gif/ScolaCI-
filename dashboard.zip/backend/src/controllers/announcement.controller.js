const AnnouncementModel = require('../models/announcement.model');
const { successResponse, errorResponse } = require('../utils/response');

exports.createAnnouncement = async (req, res) => {
  try {
    const ann = await AnnouncementModel.create({ ...req.body, author_id: req.user.id });
    successResponse(res, 201, 'Annonce créée', ann);
  } catch (err) { errorResponse(res, 500, 'Erreur', err.message); }
};

exports.getAnnouncements = async (req, res) => {
  try {
    const ann = await AnnouncementModel.findBySchoolAndRole(req.query.school_id, req.user.role);
    successResponse(res, 200, 'Annonces', ann);
  } catch (err) { errorResponse(res, 500, 'Erreur', err.message); }
};
