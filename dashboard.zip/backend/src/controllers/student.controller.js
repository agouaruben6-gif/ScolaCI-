const StudentModel = require('../models/student.model');
const ScheduleModel = require('../models/schedule.model');
const AttendanceModel = require('../models/attendance.model');
const GradeModel = require('../models/grade.model');
const { successResponse, errorResponse } = require('../utils/response');

exports.getProfile = async (req, res) => {
  try {
    const student = await StudentModel.findByUserId(req.user.id);
    successResponse(res, 200, 'Profil', student);
  } catch (err) { errorResponse(res, 500, 'Erreur', err.message); }
};

exports.getSchedule = async (req, res) => {
  try {
    const student = await StudentModel.findByUserId(req.user.id);
    const schedule = await ScheduleModel.findByClass(student.class_id);
    successResponse(res, 200, 'Emploi du temps', schedule);
  } catch (err) { errorResponse(res, 500, 'Erreur', err.message); }
};
