const TeacherModel = require('../models/teacher.model');
const ScheduleModel = require('../models/schedule.model');
const AttendanceModel = require('../models/attendance.model');
const GradeModel = require('../models/grade.model');
const { successResponse, errorResponse } = require('../utils/response');

exports.getProfile = async (req, res) => {
  try {
    const teacher = await TeacherModel.findByUserId(req.user.id);
    successResponse(res, 200, 'Profil', teacher);
  } catch (err) { errorResponse(res, 500, 'Erreur', err.message); }
};

exports.getSchedule = async (req, res) => {
  try {
    const teacher = await TeacherModel.findByUserId(req.user.id);
    const schedule = await ScheduleModel.findByTeacher(teacher.id);
    successResponse(res, 200, 'Emploi du temps', schedule);
  } catch (err) { errorResponse(res, 500, 'Erreur', err.message); }
};

exports.recordAttendance = async (req, res) => {
  try {
    const attendance = await AttendanceModel.create(req.body);
    successResponse(res, 201, 'Présence enregistrée', attendance);
  } catch (err) { errorResponse(res, 500, 'Erreur', err.message); }
};

exports.addGrade = async (req, res) => {
  try {
    const grade = await GradeModel.create(req.body);
    successResponse(res, 201, 'Note ajoutée', grade);
  } catch (err) { errorResponse(res, 500, 'Erreur', err.message); }
};
