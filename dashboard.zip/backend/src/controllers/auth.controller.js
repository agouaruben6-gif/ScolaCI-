const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const UserModel = require('../models/user.model');
const SchoolModel = require('../models/school.model');
const jwtConfig = require('../config/jwt');
const { successResponse, errorResponse } = require('../utils/response');

const login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await UserModel.findByEmail(email);

    if (!user) {
      return errorResponse(res, 401, 'Email ou mot de passe incorrect');
    }

    const isValidPassword = await bcrypt.compare(password, user.password_hash);
    if (!isValidPassword) {
      return errorResponse(res, 401, 'Email ou mot de passe incorrect');
    }

    const token = jwt.sign(
      { id: user.id, role: user.role, email: user.email },
      jwtConfig.secret,
      { expiresIn: jwtConfig.expiresIn }
    );

    successResponse(res, 200, 'Connexion réussie', {
      user: { id: user.id, email: user.email, role: user.role, first_name: user.first_name, last_name: user.last_name },
      token
    });
  } catch (err) {
    errorResponse(res, 500, 'Erreur lors de la connexion', err.message);
  }
};

const registerSchool = async (req, res) => {
  try {
    const { user_email, user_password, first_name, last_name, phone, school_name, school_type, evaluation_system } = req.body;
    
    // Check if user exists
    let user = await UserModel.findByEmail(user_email);
    if (user) return errorResponse(res, 400, 'Cet email est déjà utilisé');

    const password_hash = await bcrypt.hash(user_password, 10);
    user = await UserModel.create({
      email: user_email,
      password_hash,
      role: 'admin',
      first_name,
      last_name,
      phone
    });

    const school = await SchoolModel.create({
      name: school_name,
      type: school_type,
      admin_id: user.id,
      evaluation_system
    });

    successResponse(res, 201, 'École enregistrée avec succès', { user, school });
  } catch (err) {
    errorResponse(res, 500, 'Erreur lors de l\'enregistrement', err.message);
  }
};

const getMe = async (req, res) => {
  try {
    const user = await UserModel.findById(req.user.id);
    if (!user) return errorResponse(res, 404, 'Utilisateur non trouvé');
    delete user.password_hash;
    successResponse(res, 200, 'Profil récupéré', user);
  } catch (err) {
    errorResponse(res, 500, 'Erreur serveur', err.message);
  }
};

module.exports = { login, registerSchool, getMe };
