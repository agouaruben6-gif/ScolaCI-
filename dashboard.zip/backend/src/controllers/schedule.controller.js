const ScheduleModel = require('../models/schedule.model');
const { successResponse, errorResponse } = require('../utils/response');

exports.createSchedule = async (req, res) => {
  try {
    const schedule = await ScheduleModel.create(req.body);
    successResponse(res, 201, 'Horaire ajouté', schedule);
  } catch (err) { errorResponse(res, 500, 'Erreur', err.message); }
};

exports.getByClass = async (req, res) => {
  try {
    const schedule = await ScheduleModel.findByClass(req.params.classId);
    successResponse(res, 200, 'Horaires', schedule);
  } catch (err) { errorResponse(res, 500, 'Erreur', err.message); }
};
