const NotificationModel = require('../models/notification.model');
const { successResponse, errorResponse } = require('../utils/response');

exports.getNotifications = async (req, res) => {
  try {
    const notifs = await NotificationModel.findByUser(req.user.id);
    successResponse(res, 200, 'Notifications', notifs);
  } catch (err) { errorResponse(res, 500, 'Erreur', err.message); }
};

exports.sendNotification = async (req, res) => {
  try {
    const notif = await NotificationModel.create(req.body);
    successResponse(res, 201, 'Notification envoyée', notif);
  } catch (err) { errorResponse(res, 500, 'Erreur', err.message); }
};
