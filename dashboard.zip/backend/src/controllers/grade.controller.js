const GradeModel = require('../models/grade.model');
const { successResponse, errorResponse } = require('../utils/response');

exports.addGrade = async (req, res) => {
  try {
    const grade = await GradeModel.create({ ...req.body, recorded_by: req.user.id });
    successResponse(res, 201, 'Note ajoutée', grade);
  } catch (err) { errorResponse(res, 500, 'Erreur', err.message); }
};

exports.getGrades = async (req, res) => {
  try {
    const grades = await GradeModel.findByTeacherClassSubject(req.user.id, req.params.classId, req.params.subjectId);
    successResponse(res, 200, 'Notes', grades);
  } catch (err) { errorResponse(res, 500, 'Erreur', err.message); }
};

exports.submitGrades = async (req, res) => {
  try {
    const { class_id, subject_id, period } = req.body;
    await GradeModel.submitGrades(class_id, subject_id, req.user.id, period);
    successResponse(res, 200, 'Notes soumises avec succès', null);
  } catch (err) { errorResponse(res, 500, 'Erreur', err.message); }
};
