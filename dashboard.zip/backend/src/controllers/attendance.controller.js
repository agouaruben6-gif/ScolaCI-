const AttendanceModel = require('../models/attendance.model');
const { successResponse, errorResponse } = require('../utils/response');

exports.record = async (req, res) => {
  try {
    const attendance = await AttendanceModel.create(req.body);
    successResponse(res, 201, 'Présence enregistrée', attendance);
  } catch (err) { errorResponse(res, 500, 'Erreur', err.message); }
};

exports.getByClassAndDate = async (req, res) => {
  try {
    const { classId, date } = req.params;
    const att = await AttendanceModel.findByClassAndDate(classId, date);
    successResponse(res, 200, 'Présences', att);
  } catch (err) { errorResponse(res, 500, 'Erreur', err.message); }
};
