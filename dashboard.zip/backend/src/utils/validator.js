const { validationResult } = require('express-validator');
const { errorResponse } = require('./response');

const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (errors.isEmpty()) {
    return next();
  }
  
  const extractedErrors = [];
  errors.array().map(err => extractedErrors.push({ [err.path]: err.msg }));

  return errorResponse(res, 422, 'Erreur de validation', extractedErrors);
};

module.exports = {
  validate
};
