/**
 * Formate une réponse de succès
 * @param {Object} res - Objet de réponse Express
 * @param {Number} statusCode - Code de statut HTTP
 * @param {String} message - Message de succès
 * @param {Object|Array} data - Données à renvoyer
 */
const successResponse = (res, statusCode = 200, message = 'Succès', data = {}) => {
  return res.status(statusCode).json({
    success: true,
    message,
    data,
    error: null
  });
};

/**
 * Formate une réponse d'erreur
 * @param {Object} res - Objet de réponse Express
 * @param {Number} statusCode - Code de statut HTTP
 * @param {String} message - Message d'erreur
 * @param {Object} error - Détails de l'erreur
 */
const errorResponse = (res, statusCode = 500, message = 'Erreur serveur', error = null) => {
  return res.status(statusCode).json({
    success: false,
    message,
    data: null,
    error
  });
};

module.exports = {
  successResponse,
  errorResponse
};
