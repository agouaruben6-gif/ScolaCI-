module.exports = {
  secret: process.env.JWT_SECRET || 'secret_par_defaut',
  expiresIn: process.env.JWT_EXPIRES_IN || '24h',
  refreshSecret: process.env.JWT_REFRESH_SECRET || 'refresh_secret_par_defaut',
  refreshExpiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d'
};
