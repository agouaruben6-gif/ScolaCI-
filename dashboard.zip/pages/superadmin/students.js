/**
 * Logique pour la page Gestion des Étudiants (SuperAdmin)
 */

let allStudents = [];
let filteredStudents = [];

document.addEventListener('DOMContentLoaded', async () => {
    await loadEstablishments();
    await loadStudents();
    
    // Écouteurs filtres/recherche
    document.getElementById('studentSearch').addEventListener('input', filterStudents);
    document.getElementById('filterSchool').addEventListener('change', filterStudents);
    document.getElementById('filterClass').addEventListener('change', filterStudents);

    // Notifications panel logic
    const notifBtn = document.getElementById('notificationBtn');
    const notifPanel = document.getElementById('notificationsPanel');
    const overlay = document.getElementById('mainOverlay');
    const closeNotif = document.getElementById('closeNotifications');

    if(notifBtn) {
        notifBtn.addEventListener('click', () => {
            notifPanel.classList.add('active');
            overlay.classList.add('active');
        });
    }

    if(closeNotif && overlay) {
        const close = () => {
            notifPanel.classList.remove('active');
            overlay.classList.remove('active');
        };
        closeNotif.addEventListener('click', close);
        overlay.addEventListener('click', close);
    }
});

async function loadEstablishments() {
    // Si la methode n'existe pas, on simule
    const schools = typeof DataService.getEstablishments === 'function' 
        ? await DataService.getEstablishments() 
        : [];
        
    const filterSelect = document.getElementById('filterSchool');
    const modalSelect = document.getElementById('studentSchool');
    
    let options = '';
    schools.forEach(s => {
        options += `<option value="${s.id}">${s.name}</option>`;
    });
    
    if(filterSelect) filterSelect.insertAdjacentHTML('beforeend', options);
    if(modalSelect) {
        modalSelect.innerHTML = '<option value="">Sélectionner un établissement</option>' + options;
    }
}

async function loadStudents() {
    if(typeof DataService.getStudents === 'function') {
        allStudents = await DataService.getStudents();
    } else {
        // Mockup
        allStudents = [
            { id: 1, matricule: 'MAT2026-001', firstName: 'Kofi', lastName: 'Kouassi', gender: 'M', dob: '2010-05-12', schoolId: 1, schoolName: 'Lycée Classique', className: 'Seconde', parentName: 'Ayao Kouassi', parentPhone: '01010101', status: 'Inscrit' },
            { id: 2, matricule: 'MAT2026-002', firstName: 'Awa', lastName: 'Diop', gender: 'F', dob: '2011-08-22', schoolId: 2, schoolName: 'Collège Moderne', className: '3ème', parentName: 'Moussa Diop', parentPhone: '02020202', status: 'Inscrit' }
        ];
    }
    filteredStudents = [...allStudents];
    updateStats();
    renderStudents();
}

function updateStats() {
    document.getElementById('statTotalStudents').textContent = allStudents.length;
    document.getElementById('statInscrits').textContent = allStudents.filter(s => s.status === 'Inscrit').length;
    
    const garcons = allStudents.filter(s => s.gender === 'M').length;
    const filles = allStudents.filter(s => s.gender === 'F').length;
    document.getElementById('statGenderRatio').textContent = `${garcons} / ${filles}`;
}

function filterStudents() {
    const search = document.getElementById('studentSearch').value.toLowerCase();
    const schoolId = document.getElementById('filterSchool').value;
    const className = document.getElementById('filterClass').value;
    
    filteredStudents = allStudents.filter(s => {
        const matchSearch = s.matricule.toLowerCase().includes(search) || 
                            (s.firstName + ' ' + s.lastName).toLowerCase().includes(search);
        const matchSchool = schoolId ? s.schoolId == schoolId : true;
        const matchClass = className ? s.className === className : true;
        
        return matchSearch && matchSchool && matchClass;
    });
    
    renderStudents();
}

function renderStudents() {
    const tbody = document.getElementById('studentsTableBody');
    tbody.innerHTML = '';
    
    if (filteredStudents.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;">Aucun étudiant trouvé.</td></tr>';
        return;
    }
    
    filteredStudents.forEach(s => {
        const avatar = `https://ui-avatars.com/api/?name=${s.firstName}+${s.lastName}&background=random`;
        const badgeClass = s.status === 'Inscrit' ? 'badge-success' : 'badge-secondary';
        
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>
                <div class="student-info">
                    <img src="${avatar}" alt="avatar" class="student-avatar">
                    <div>
                        <div class="student-name">${s.firstName} ${s.lastName}</div>
                        <div class="student-matricule">${s.matricule}</div>
                    </div>
                </div>
            </td>
            <td>${s.schoolName}</td>
            <td>${s.className}</td>
            <td>
                <div>${s.parentName || '-'}</div>
                <div style="font-size: 0.8rem; color: var(--text-secondary);">${s.parentPhone || '-'}</div>
            </td>
            <td><span class="badge ${badgeClass}">${s.status || 'Inscrit'}</span></td>
            <td>
                <div style="display:flex; gap:0.5rem;">
                    <button class="btn-icon edit" onclick="editStudent(${s.id})" title="Éditer"><i class="fas fa-edit"></i></button>
                    <button class="btn-icon delete" onclick="deleteStudent(${s.id})" title="Supprimer"><i class="fas fa-trash"></i></button>
                </div>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function generateMatricule() {
    const year = new Date().getFullYear();
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    document.getElementById('studentMatricule').value = `MAT${year}-${random}`;
}

function openStudentModal() {
    document.getElementById('studentForm').reset();
    document.getElementById('studentId').value = '';
    document.getElementById('modalTitle').textContent = 'Inscrire un étudiant';
    document.getElementById('studentModal').classList.add('active');
}

function closeStudentModal() {
    document.getElementById('studentModal').classList.remove('active');
}

function editStudent(id) {
    const student = allStudents.find(s => s.id === id);
    if (!student) return;
    
    document.getElementById('studentId').value = student.id;
    document.getElementById('studentMatricule').value = student.matricule;
    document.getElementById('studentFirstName').value = student.firstName;
    document.getElementById('studentLastName').value = student.lastName;
    document.getElementById('studentDob').value = student.dob || '';
    document.getElementById('studentGender').value = student.gender || 'M';
    document.getElementById('studentSchool').value = student.schoolId || '';
    document.getElementById('studentClass').value = student.className || '';
    document.getElementById('parentName').value = student.parentName || '';
    document.getElementById('parentPhone').value = student.parentPhone || '';
    
    document.getElementById('modalTitle').textContent = 'Éditer l\'étudiant';
    document.getElementById('studentModal').classList.add('active');
}

function saveStudent() {
    const id = document.getElementById('studentId').value;
    const schoolSelect = document.getElementById('studentSchool');
    const schoolName = schoolSelect.options[schoolSelect.selectedIndex]?.text || '';
    
    let matricule = document.getElementById('studentMatricule').value;
    if(!matricule) {
        const year = new Date().getFullYear();
        const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
        matricule = `MAT${year}-${random}`;
    }

    if(!document.getElementById('studentFirstName').value || !document.getElementById('studentLastName').value || !document.getElementById('studentSchool').value || !document.getElementById('studentClass').value) {
        showToast('Veuillez remplir les champs obligatoires.', 'error');
        return;
    }

    const studentData = {
        id: id ? parseInt(id) : Date.now(),
        matricule: matricule,
        firstName: document.getElementById('studentFirstName').value,
        lastName: document.getElementById('studentLastName').value,
        dob: document.getElementById('studentDob').value,
        gender: document.getElementById('studentGender').value,
        schoolId: document.getElementById('studentSchool').value,
        schoolName: schoolName,
        className: document.getElementById('studentClass').value,
        parentName: document.getElementById('parentName').value,
        parentPhone: document.getElementById('parentPhone').value,
        status: 'Inscrit'
    };
    
    if (id) {
        const index = allStudents.findIndex(s => s.id == id);
        if (index > -1) {
            allStudents[index] = { ...allStudents[index], ...studentData };
            showToast('Étudiant mis à jour avec succès.', 'success');
        }
    } else {
        allStudents.push(studentData);
        showToast('Étudiant inscrit avec succès.', 'success');
    }
    
    closeStudentModal();
    updateStats();
    filterStudents();
}

function deleteStudent(id) {
    if (confirm('Êtes-vous sûr de vouloir supprimer cet étudiant ?')) {
        allStudents = allStudents.filter(s => s.id !== id);
        updateStats();
        filterStudents();
        showToast('Étudiant supprimé.', 'success');
    }
}

function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    
    const bgColor = type === 'success' ? 'var(--success-color)' : 'var(--danger-color)';
    
    toast.style.cssText = `
        background-color: ${bgColor};
        color: white;
        padding: 12px 20px;
        border-radius: 4px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        display: flex;
        align-items: center;
        gap: 10px;
        animation: slideInRight 0.3s ease-out forwards;
    `;
    
    const icon = type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle';
    toast.innerHTML = `<i class="fas ${icon}"></i> <span>${message}</span>`;
    
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'fadeOut 0.3s ease-in forwards';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
    @keyframes fadeOut { from { opacity: 1; } to { opacity: 0; } }
`;
document.head.appendChild(style);
