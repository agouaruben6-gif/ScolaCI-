// ==========================================
// SCOLACI - DASHBOARD SUPERADMIN
// ==========================================

// Injection des styles pour le Mini-calendrier et le Chat IA
(function injectStyles() {
    const style = document.createElement('style');
    style.innerHTML = `
        /* Styles Mini Calendrier */
        .mini-calendar { font-size: 14px; }
        .mini-calendar .cal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
        .mini-calendar .cal-header h4 { font-size: 16px; font-weight: 600; text-transform: capitalize; }
        .mini-calendar .cal-header button { background: none; border: none; cursor: pointer; font-size: 18px; color: #0A84FF; padding: 5px 10px; border-radius: 8px; transition: .3s; }
        .mini-calendar .cal-header button:hover { background: #EEF5FF; }
        .mini-calendar .cal-grid { display: grid; grid-template-columns: repeat(7, 1fr); text-align: center; gap: 4px; }
        .mini-calendar .cal-day-name { font-weight: 600; color: #6E6E73; font-size: 12px; padding: 8px 0; }
        .mini-calendar .cal-day { padding: 8px; border-radius: 10px; cursor: pointer; transition: .2s; font-weight: 500; }
        .mini-calendar .cal-day:hover { background: #EEF5FF; }
        .mini-calendar .cal-day.today { background: #0A84FF; color: white; font-weight: 700; }
        .mini-calendar .cal-day.other-month { color: #D2D2D7; }

        /* Styles Chat IA */
        .ai-chat-panel { position: fixed; bottom: 110px; right: 30px; width: 380px; height: 500px; background: #FFFFFF; border-radius: 24px; box-shadow: 0 25px 60px rgba(0,0,0,.15); z-index: 1001; display: flex; flex-direction: column; overflow: hidden; transform: scale(0) translateY(20px); transform-origin: bottom right; opacity: 0; transition: transform .35s cubic-bezier(.34,1.56,.64,1), opacity .25s; }
        .ai-chat-panel.open { transform: scale(1) translateY(0); opacity: 1; }
        .ai-chat-header { display: flex; justify-content: space-between; align-items: center; padding: 20px; background: linear-gradient(135deg, #0A84FF, #5E5CE6); color: white; }
        .ai-chat-header div { display: flex; align-items: center; gap: 12px; }
        .ai-chat-header h3 { font-size: 18px; margin: 0; }
        .ai-chat-header i { font-size: 22px; }
        .ai-chat-header button { background: rgba(255,255,255,.2); border: none; color: white; width: 35px; height: 35px; border-radius: 50%; cursor: pointer; font-size: 16px; display: flex; align-items: center; justify-content: center; transition: .3s; }
        .ai-chat-header button:hover { background: rgba(255,255,255,.35); }
        .ai-chat-messages { flex: 1; overflow-y: auto; padding: 20px; display: flex; flex-direction: column; gap: 12px; }
        .ai-message { max-width: 85%; padding: 12px 16px; border-radius: 18px; font-size: 14px; line-height: 1.5; }
        .ai-message p { margin: 0; }
        .ai-message.bot { background: #F0F0F5; color: #1D1D1F; align-self: flex-start; border-bottom-left-radius: 6px; }
        .ai-message.user { background: linear-gradient(135deg, #0A84FF, #5E5CE6); color: white; align-self: flex-end; border-bottom-right-radius: 6px; }
        .ai-chat-input { display: flex; padding: 15px; gap: 10px; border-top: 1px solid #E5E5EA; }
        .ai-chat-input input { flex: 1; border: 1px solid #D2D2D7; border-radius: 14px; padding: 12px 16px; font-size: 14px; outline: none; font-family: 'Inter', sans-serif; transition: .3s; }
        .ai-chat-input input:focus { border-color: #0A84FF; box-shadow: 0 0 0 4px rgba(10,132,255,.12); }
        .ai-chat-input button { width: 45px; height: 45px; border-radius: 14px; border: none; background: linear-gradient(135deg, #0A84FF, #5E5CE6); color: white; cursor: pointer; font-size: 16px; display: flex; align-items: center; justify-content: center; transition: .3s; }
        .ai-chat-input button:hover { transform: scale(1.05); }

        /* Dark mode chat & calendar support */
        body.dark .ai-chat-panel { background: #2C2C2E; }
        body.dark .ai-chat-header { background: linear-gradient(135deg, #0A84FF, #5E5CE6); }
        body.dark .ai-message.bot { background: #3A3A3C; color: #F5F5F7; }
        body.dark .ai-chat-input { border-color: #38383A; }
        body.dark .ai-chat-input input { background: #3A3A3C; border-color: #48484A; color: #F5F5F7; }
        body.dark .mini-calendar .cal-day:hover { background: #3A3A3C; }
        body.dark .mini-calendar .cal-day-name { color: #A1A1A6; }
        body.dark .mini-calendar .cal-header h4 { color: #F5F5F7; }
        body.dark .mini-calendar .cal-header button:hover { background: #3A3A3C; }
    `;
    document.head.appendChild(style);
})();

let currentCalDate = new Date();

document.addEventListener('DOMContentLoaded', () => {
    // 1. Initialiser le graphique
    initChart();
    
    // 2. Initialiser le calendrier
    renderCalendar();
    
    // 3. Gestion de l'état actif du menu sidebar
    document.querySelectorAll('.menu li').forEach(item => {
        item.addEventListener('click', function() {
            document.querySelectorAll('.menu li').forEach(li => li.classList.remove('active'));
            this.classList.add('active');
        });
    });

    // 4. Animer les compteurs numériques
    const counters = document.querySelectorAll('.card h2');
    counters.forEach(counter => {
        const textValue = counter.innerText.trim();
        const isPercentage = textValue.includes('%');
        // Extraire seulement les nombres
        const targetValue = parseInt(textValue.replace(/\\D/g, ''));
        
        const duration = 2000; // 2 secondes
        let startTime = null;
        
        function animateNumber(currentTime) {
            if (!startTime) startTime = currentTime;
            const progress = Math.min((currentTime - startTime) / duration, 1);
            
            // Easing (easeOutQuart)
            const easeOutProgress = 1 - Math.pow(1 - progress, 4);
            const currentVal = Math.floor(easeOutProgress * targetValue);
            
            // Formater le nombre
            let formattedValue = currentVal.toLocaleString('fr-FR');
            if (isPercentage) {
                formattedValue += '%';
            }
            
            counter.innerText = formattedValue;
            
            if (progress < 1) {
                requestAnimationFrame(animateNumber);
            } else {
                // S'assurer qu'on affiche bien la valeur cible à la fin
                let finalFormatted = targetValue.toLocaleString('fr-FR');
                if (isPercentage) {
                    finalFormatted += '%';
                }
                counter.innerText = finalFormatted;
            }
        }
        
        requestAnimationFrame(animateNumber);
    });
});

window.addEventListener('load', () => {
    // Animer les cartes de stats
    document.querySelectorAll('.card').forEach((card, i) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(30px)';
        setTimeout(() => {
            card.style.transition = '0.6s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, 100 + i * 100);
    });
    
    // Animer les panneaux
    document.querySelectorAll('.panel').forEach((panel, i) => {
        panel.style.opacity = '0';
        panel.style.transform = 'translateY(20px)';
        setTimeout(() => {
            panel.style.transition = '0.6s ease';
            panel.style.opacity = '1';
            panel.style.transform = 'translateY(0)';
        }, 300 + i * 80);
    });
});

// ==========================================
// FONCTIONS GLOBALES
// ==========================================

// Initialisation du Chart.js
function initChart() {
    const ctx = document.getElementById('mainChart');
    if (!ctx) return;
    
    // Créer un dégradé pour les barres
    const gradient = ctx.getContext('2d').createLinearGradient(0, 0, 0, 320);
    gradient.addColorStop(0, 'rgba(10, 132, 255, 0.8)');
    gradient.addColorStop(1, 'rgba(10, 132, 255, 0.2)');

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun', 'Jul', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc'],
            datasets: [
                {
                    type: 'line',
                    label: 'Présence (%)',
                    data: [92, 94, 91, 95, 96, 93, 97, 95, 98, 96, 97, 97],
                    borderColor: '#30D158',
                    backgroundColor: '#30D158',
                    borderWidth: 3,
                    tension: 0.4,
                    yAxisID: 'y1'
                },
                {
                    type: 'bar',
                    label: 'Inscriptions',
                    data: [120, 190, 230, 280, 310, 350, 290, 380, 420, 450, 410, 480],
                    backgroundColor: gradient,
                    borderWidth: 0,
                    borderRadius: 6,
                    yAxisID: 'y'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(0, 0, 0, 0.05)' }
                },
                y1: {
                    beginAtZero: true,
                    position: 'right',
                    grid: { drawOnChartArea: false },
                    max: 100
                },
                x: {
                    grid: { display: false }
                }
            }
        }
    });
}

// Fonctionnalité Mini-calendrier
function renderCalendar() {
    const calendarEl = document.getElementById('miniCalendar');
    if (!calendarEl) return;
    
    const year = currentCalDate.getFullYear();
    const month = currentCalDate.getMonth();
    
    const firstDayIndex = new Date(year, month, 1).getDay(); // 0 (Dim) - 6 (Sam)
    const lastDayDate = new Date(year, month + 1, 0).getDate();
    const prevLastDayDate = new Date(year, month, 0).getDate();
    
    // Ajuster l'index du premier jour (Lundi = 0, Dimanche = 6)
    const startDay = firstDayIndex === 0 ? 6 : firstDayIndex - 1;
    
    const monthNames = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];
    
    let html = \`
        <div class="cal-header">
            <button onclick="changeMonth(-1)"><i class="fa-solid fa-chevron-left"></i></button>
            <h4>\${monthNames[month]} \${year}</h4>
            <button onclick="changeMonth(1)"><i class="fa-solid fa-chevron-right"></i></button>
        </div>
        <div class="cal-grid">
            <div class="cal-day-name">Lun</div>
            <div class="cal-day-name">Mar</div>
            <div class="cal-day-name">Mer</div>
            <div class="cal-day-name">Jeu</div>
            <div class="cal-day-name">Ven</div>
            <div class="cal-day-name">Sam</div>
            <div class="cal-day-name">Dim</div>
    \`;
    
    const today = new Date();
    
    let daysHtml = '';
    // Jours du mois précédent
    for (let i = startDay; i > 0; i--) {
        daysHtml += \`<div class="cal-day other-month">\${prevLastDayDate - i + 1}</div>\`;
    }
    
    // Jours du mois actuel
    for (let i = 1; i <= lastDayDate; i++) {
        if (i === today.getDate() && month === today.getMonth() && year === today.getFullYear()) {
            daysHtml += \`<div class="cal-day today">\${i}</div>\`;
        } else {
            daysHtml += \`<div class="cal-day">\${i}</div>\`;
        }
    }
    
    // Jours du mois suivant
    const totalDaysSlots = startDay + lastDayDate;
    const nextDays = 42 - totalDaysSlots; // S'assurer de remplir 6 rangées
    for (let i = 1; i <= nextDays; i++) {
        daysHtml += \`<div class="cal-day other-month">\${i}</div>\`;
    }
    
    html += daysHtml + \`</div>\`;
    calendarEl.innerHTML = html;
}

window.changeMonth = function(dir) {
    currentCalDate.setMonth(currentCalDate.getMonth() + dir);
    renderCalendar();
};

// Toggle Notifications
function toggleNotifications() {
    const panel = document.querySelector('.notification-panel');
    const overlay = document.querySelector('.notification-overlay');
    if (panel) panel.classList.toggle('open');
    if (overlay) overlay.classList.toggle('open');
}

// Toggle Sidebar
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) sidebar.classList.toggle('open');
}

// Fermer sidebar en cliquant en dehors (mobile)
document.addEventListener('click', (e) => {
    const sidebar = document.querySelector('.sidebar');
    const hamburger = document.querySelector('.hamburger');
    if (window.innerWidth <= 600 && sidebar && sidebar.classList.contains('open')) {
        if (!sidebar.contains(e.target) && hamburger && !hamburger.contains(e.target)) {
            sidebar.classList.remove('open');
        }
    }
});

// Chat IA Toggle
function toggleAIChat() {
    const panel = document.getElementById('aiChatPanel');
    if(panel) panel.classList.toggle('open');
}

// Envoyer un message IA
function sendAIMessage() {
    const input = document.getElementById('aiInput');
    const msg = input.value.trim();
    if (!msg) return;
    
    // Ajouter le message utilisateur
    addChatMessage(msg, 'user');
    input.value = '';
    
    // Réponse IA simulée après un délai
    setTimeout(() => {
        const response = getAIResponse(msg);
        addChatMessage(response, 'bot');
    }, 800);
}

// Ajouter un message à la vue du chat
function addChatMessage(text, type) {
    const container = document.getElementById('aiMessages');
    if (!container) return;
    
    const div = document.createElement('div');
    div.className = \`ai-message \${type}\`;
    div.innerHTML = \`<p>\${text}</p>\`;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
}

// Obtenir une réponse IA prédéfinie
function getAIResponse(message) {
    const msg = message.toLowerCase();
    if (msg.includes('étudiant') || msg.includes('student')) return '📊 Nous avons actuellement 52 814 étudiants inscrits sur la plateforme ScolaCI, répartis dans 285 établissements.';
    if (msg.includes('enseignant') || msg.includes('professeur')) return '👨‍🏫 Il y a 2 346 enseignants enregistrés. Le taux de satisfaction est de 94%.';
    if (msg.includes('établissement') || msg.includes('école')) return '🏫 285 établissements sont actifs sur ScolaCI, répartis dans 12 pays.';
    if (msg.includes('paiement') || msg.includes('revenu')) return '💰 Les revenus du mois en cours s\\'élèvent à $125,000, soit une hausse de 18% par rapport au mois dernier.';
    if (msg.includes('présence') || msg.includes('absence')) return '📅 Le taux de présence global est de 97%. Les absences sont principalement concentrées le vendredi.';
    if (msg.includes('aide') || msg.includes('help')) return '🤖 Je peux vous aider avec : les statistiques des étudiants, enseignants, établissements, paiements, présences et bien plus !';
    if (msg.includes('bonjour') || msg.includes('salut') || msg.includes('hello')) return '👋 Bonjour ! Comment puis-je vous aider aujourd\\'hui ?';
    return '🤔 Je comprends votre question. Pour une réponse plus précise, essayez de me demander des informations sur les étudiants, enseignants, établissements ou paiements.';
}
