/**
 * Logique pour la page Gestion des Enseignants (SuperAdmin)
 */

let allTeachers = [];
let filteredTeachers = [];
let currentView = 'grid'; // 'grid' ou 'table'

document.addEventListener('DOMContentLoaded', async () => {
    // Initialisation
    await loadEstablishments();
    await loadTeachers();
    
    // Écouteurs d'événements pour filtres et recherche
    document.getElementById('teacherSearch').addEventListener('input', filterTeachers);
    document.getElementById('filterSchool').addEventListener('change', filterTeachers);
    document.getElementById('filterSubject').addEventListener('change', filterTeachers);
    
    // Notifications panel logic
    const notifBtn = document.getElementById('notificationBtn');
    const notifPanel = document.getElementById('notificationsPanel');
    const overlay = document.getElementById('mainOverlay');
    const closeNotif = document.getElementById('closeNotifications');

    if(notifBtn) {
        notifBtn.addEventListener('click', () => {
            notifPanel.classList.add('active');
            overlay.classList.add('active');
        });
    }

    if(closeNotif && overlay) {
        const close = () => {
            notifPanel.classList.remove('active');
            overlay.classList.remove('active');
        };
        closeNotif.addEventListener('click', close);
        overlay.addEventListener('click', close);
    }
});

/**
 * Charge les établissements pour les menus déroulants
 */
async function loadEstablishments() {
    const schools = await DataService.getEstablishments();
    const filterSelect = document.getElementById('filterSchool');
    const modalSelect = document.getElementById('teacherSchool');
    
    let options = '';
    schools.forEach(school => {
        options += `<option value="${school.id}">${school.name}</option>`;
    });
    
    if(filterSelect) filterSelect.insertAdjacentHTML('beforeend', options);
    if(modalSelect) {
        modalSelect.innerHTML = '<option value="">Sélectionner un établissement</option>' + options;
    }
}

/**
 * Charge la liste des enseignants
 */
async function loadTeachers() {
    // Simuler un fetch avec DataService s'il existe, sinon mockup
    if(typeof DataService.getTeachers === 'function') {
        allTeachers = await DataService.getTeachers();
    } else {
        // Mockup if not available
        allTeachers = [
            { id: 1, firstName: 'Jean', lastName: 'Dupont', email: 'jean.dupont@ecole.ci', phone: '01020304', schoolId: 1, schoolName: 'Lycée Classique', subject: 'Mathématiques', contract: 'Temps Plein', status: 'Actif', avatar: 'https://ui-avatars.com/api/?name=Jean+Dupont' }
        ];
    }
    filteredTeachers = [...allTeachers];
    updateStats();
    renderTeachers();
}

/**
 * Met à jour les statistiques
 */
function updateStats() {
    document.getElementById('statTotalTeachers').textContent = allTeachers.length;
    const fullTime = allTeachers.filter(t => t.contract === 'Temps Plein').length;
    const partTime = allTeachers.filter(t => t.contract === 'Vacataire').length;
    document.getElementById('statFullTime').textContent = fullTime;
    document.getElementById('statPartTime').textContent = partTime;
}

/**
 * Filtre les enseignants selon les critères
 */
function filterTeachers() {
    const search = document.getElementById('teacherSearch').value.toLowerCase();
    const schoolId = document.getElementById('filterSchool').value;
    const subject = document.getElementById('filterSubject').value;
    
    filteredTeachers = allTeachers.filter(t => {
        const matchSearch = (t.firstName + ' ' + t.lastName).toLowerCase().includes(search) || t.email.toLowerCase().includes(search);
        const matchSchool = schoolId ? t.schoolId == schoolId : true;
        const matchSubject = subject ? t.subject === subject : true;
        
        return matchSearch && matchSchool && matchSubject;
    });
    
    renderTeachers();
}

/**
 * Bascule entre vue grille et vue tableau
 */
function toggleView(view) {
    currentView = view;
    
    const gridBtn = document.getElementById('btnGridView');
    const tableBtn = document.getElementById('btnTableView');
    const gridView = document.getElementById('teachersGridView');
    const tableView = document.getElementById('teachersTableView');
    
    if (view === 'grid') {
        gridBtn.classList.add('active');
        tableBtn.classList.remove('active');
        gridView.classList.remove('view-hidden');
        tableView.classList.add('view-hidden');
    } else {
        tableBtn.classList.add('active');
        gridBtn.classList.remove('active');
        tableView.classList.remove('view-hidden');
        gridView.classList.add('view-hidden');
    }
    
    renderTeachers();
}

/**
 * Rendu des enseignants dans les vues actives
 */
function renderTeachers() {
    const gridContainer = document.getElementById('teachersGridView');
    const tableBody = document.getElementById('teachersTableBody');
    
    gridContainer.innerHTML = '';
    tableBody.innerHTML = '';
    
    if (filteredTeachers.length === 0) {
        gridContainer.innerHTML = '<p style="grid-column: 1/-1; text-align:center; padding: 2rem;">Aucun enseignant trouvé.</p>';
        tableBody.innerHTML = '<tr><td colspan="7" style="text-align:center;">Aucun enseignant trouvé.</td></tr>';
        return;
    }
    
    filteredTeachers.forEach(teacher => {
        const avatar = teacher.avatar || `https://ui-avatars.com/api/?name=${teacher.firstName}+${teacher.lastName}&background=random`;
        const badgeClass = teacher.status === 'Actif' ? 'badge-success' : 'badge-warning';
        
        // Rendu Grille
        const card = document.createElement('div');
        card.className = 'teacher-card';
        card.innerHTML = `
            <img src="${avatar}" alt="${teacher.firstName}" class="teacher-avatar">
            <h4 class="teacher-name">${teacher.firstName} ${teacher.lastName}</h4>
            <div class="teacher-subject">${teacher.subject}</div>
            <div class="teacher-school"><i class="fas fa-school"></i> ${teacher.schoolName}</div>
            <span class="badge ${badgeClass}">${teacher.status || 'Actif'}</span>
            <div class="teacher-actions">
                <button class="btn-icon contact" title="Contacter" onclick="contactTeacher(${teacher.id})"><i class="fas fa-envelope"></i></button>
                <button class="btn-icon edit" title="Éditer" onclick="editTeacher(${teacher.id})"><i class="fas fa-edit"></i></button>
                <button class="btn-icon delete" title="Supprimer" onclick="deleteTeacher(${teacher.id})"><i class="fas fa-trash"></i></button>
            </div>
        `;
        gridContainer.appendChild(card);
        
        // Rendu Tableau
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td><img src="${avatar}" alt="avatar" style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover;"></td>
            <td><strong>${teacher.firstName} ${teacher.lastName}</strong></td>
            <td>
                <div>${teacher.email}</div>
                <div style="font-size: 0.8rem; color: var(--text-secondary);">${teacher.phone || '-'}</div>
            </td>
            <td>${teacher.subject}</td>
            <td>${teacher.schoolName}</td>
            <td><span class="badge ${badgeClass}">${teacher.status || 'Actif'}</span></td>
            <td>
                <div style="display:flex; gap:0.5rem;">
                    <button class="btn-icon edit" onclick="editTeacher(${teacher.id})"><i class="fas fa-edit"></i></button>
                    <button class="btn-icon delete" onclick="deleteTeacher(${teacher.id})"><i class="fas fa-trash"></i></button>
                </div>
            </td>
        `;
        tableBody.appendChild(tr);
    });
}

/**
 * Gestion de la modale Ajouter/Éditer
 */
function openTeacherModal() {
    document.getElementById('teacherForm').reset();
    document.getElementById('teacherId').value = '';
    document.getElementById('modalTitle').textContent = 'Ajouter un enseignant';
    document.getElementById('teacherModal').classList.add('active');
}

function closeTeacherModal() {
    document.getElementById('teacherModal').classList.remove('active');
}

function editTeacher(id) {
    const teacher = allTeachers.find(t => t.id === id);
    if (!teacher) return;
    
    document.getElementById('teacherId').value = teacher.id;
    document.getElementById('teacherFirstName').value = teacher.firstName;
    document.getElementById('teacherLastName').value = teacher.lastName;
    document.getElementById('teacherEmail').value = teacher.email;
    document.getElementById('teacherPhone').value = teacher.phone || '';
    document.getElementById('teacherSchool').value = teacher.schoolId || '';
    document.getElementById('teacherSubject').value = teacher.subject;
    document.getElementById('teacherContract').value = teacher.contract;
    document.getElementById('teacherAvatar').value = teacher.avatar || '';
    
    document.getElementById('modalTitle').textContent = 'Éditer l\'enseignant';
    document.getElementById('teacherModal').classList.add('active');
}

function saveTeacher() {
    const id = document.getElementById('teacherId').value;
    const schoolSelect = document.getElementById('teacherSchool');
    const schoolName = schoolSelect.options[schoolSelect.selectedIndex].text;
    
    // Validation basique
    if(!document.getElementById('teacherFirstName').value || !document.getElementById('teacherLastName').value) {
        showToast('Veuillez remplir les champs obligatoires.', 'error');
        return;
    }

    const teacherData = {
        id: id ? parseInt(id) : Date.now(), // Fake ID pour test
        firstName: document.getElementById('teacherFirstName').value,
        lastName: document.getElementById('teacherLastName').value,
        email: document.getElementById('teacherEmail').value,
        phone: document.getElementById('teacherPhone').value,
        schoolId: document.getElementById('teacherSchool').value,
        schoolName: schoolName,
        subject: document.getElementById('teacherSubject').value,
        contract: document.getElementById('teacherContract').value,
        avatar: document.getElementById('teacherAvatar').value,
        status: 'Actif'
    };
    
    if (id) {
        // Mise à jour
        const index = allTeachers.findIndex(t => t.id == id);
        if (index > -1) {
            allTeachers[index] = { ...allTeachers[index], ...teacherData };
            showToast('Enseignant mis à jour avec succès.', 'success');
        }
    } else {
        // Ajout
        allTeachers.push(teacherData);
        showToast('Enseignant ajouté avec succès.', 'success');
    }
    
    closeTeacherModal();
    updateStats();
    filterTeachers(); // Rafraîchit l'affichage avec les filtres actuels
}

function deleteTeacher(id) {
    if (confirm('Êtes-vous sûr de vouloir supprimer cet enseignant ?')) {
        allTeachers = allTeachers.filter(t => t.id !== id);
        updateStats();
        filterTeachers();
        showToast('Enseignant supprimé.', 'success');
    }
}

function contactTeacher(id) {
    const teacher = allTeachers.find(t => t.id === id);
    if(teacher) {
        window.location.href = `mailto:${teacher.email}`;
    }
}

/**
 * Affiche un toast de notification
 */
function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    
    const bgColor = type === 'success' ? 'var(--success-color)' : 'var(--danger-color)';
    
    toast.style.cssText = `
        background-color: ${bgColor};
        color: white;
        padding: 12px 20px;
        border-radius: 4px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        display: flex;
        align-items: center;
        gap: 10px;
        animation: slideInRight 0.3s ease-out forwards;
    `;
    
    const icon = type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle';
    toast.innerHTML = `<i class="fas ${icon}"></i> <span>${message}</span>`;
    
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'fadeOut 0.3s ease-in forwards';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Keyframe addition for toast animations if not present in CSS
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
    @keyframes fadeOut { from { opacity: 1; } to { opacity: 0; } }
`;
document.head.appendChild(style);
