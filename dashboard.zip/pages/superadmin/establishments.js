/**
 * Logique de la page Établissements.
 */

document.addEventListener('DOMContentLoaded', () => {
    // Éléments du DOM
    const tableBody = document.getElementById('table-body');
    const searchInput = document.getElementById('search-input');
    const filterCountry = document.getElementById('filter-country');
    const filterType = document.getElementById('filter-type');
    const filterStatus = document.getElementById('filter-status');
    
    // Stats
    const statTotal = document.getElementById('stat-total');
    const statActive = document.getElementById('stat-active');
    const statPending = document.getElementById('stat-pending');
    const statCountries = document.getElementById('stat-countries');
    
    // Modal
    const modalOverlay = document.getElementById('school-modal');
    const btnAdd = document.getElementById('btn-add');
    const btnCloseModal = document.getElementById('btn-close-modal');
    const btnCancelModal = document.getElementById('btn-cancel-modal');
    const schoolForm = document.getElementById('school-form');
    const modalTitle = document.getElementById('modal-title');
    
    // Initialisation
    let currentSchools = dataService.getSchools();
    initFilters();
    renderTable();
    updateStats();

    // --- Rendu du tableau ---
    function renderTable() {
        tableBody.innerHTML = '';
        
        if (currentSchools.length === 0) {
            tableBody.innerHTML = `<tr><td colspan="7" style="text-align:center;">Aucun établissement trouvé.</td></tr>`;
            return;
        }

        currentSchools.forEach(school => {
            const tr = document.createElement('tr');
            
            const statusClass = school.status === 'Actif' ? 'active' : 'pending';
            
            tr.innerHTML = `
                <td>#${school.id}</td>
                <td>
                    <strong>${school.name}</strong><br>
                    <small class="text-muted">${school.email}</small>
                </td>
                <td>${school.country}, ${school.city}</td>
                <td>${school.type}</td>
                <td>${school.studentsCount || 0}</td>
                <td><span class="badge ${statusClass}">${school.status}</span></td>
                <td class="actions-cell">
                    <button class="btn-icon view-btn" data-id="${school.id}" title="Voir"><i class="fas fa-eye"></i></button>
                    <button class="btn-icon edit-btn" data-id="${school.id}" title="Éditer"><i class="fas fa-edit"></i></button>
                    <button class="btn-icon delete-btn" data-id="${school.id}" title="Supprimer"><i class="fas fa-trash"></i></button>
                </td>
            `;
            tableBody.appendChild(tr);
        });

        // Ajouter les événements sur les boutons d'action
        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', (e) => openModal(e.currentTarget.dataset.id));
        });

        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', (e) => deleteSchool(e.currentTarget.dataset.id));
        });
    }

    // --- Filtres et Recherche ---
    function initFilters() {
        const allSchools = dataService.getSchools();
        const countries = [...new Set(allSchools.map(s => s.country))].sort();
        
        filterCountry.innerHTML = '<option value="">Tous les pays</option>';
        countries.forEach(c => {
            const option = document.createElement('option');
            option.value = c;
            option.textContent = c;
            filterCountry.appendChild(option);
        });
    }

    function applyFilters() {
        const searchTerm = searchInput.value.toLowerCase();
        const country = filterCountry.value;
        const type = filterType.value;
        const status = filterStatus.value;
        
        const allSchools = dataService.getSchools();
        
        currentSchools = allSchools.filter(school => {
            const matchSearch = school.name.toLowerCase().includes(searchTerm) || school.city.toLowerCase().includes(searchTerm);
            const matchCountry = country === "" || school.country === country;
            const matchType = type === "" || school.type === type;
            const matchStatus = status === "" || school.status === status;
            
            return matchSearch && matchCountry && matchType && matchStatus;
        });
        
        renderTable();
    }

    searchInput.addEventListener('input', applyFilters);
    filterCountry.addEventListener('change', applyFilters);
    filterType.addEventListener('change', applyFilters);
    filterStatus.addEventListener('change', applyFilters);

    // --- Statistiques ---
    function updateStats() {
        const allSchools = dataService.getSchools();
        statTotal.textContent = allSchools.length;
        statActive.textContent = allSchools.filter(s => s.status === 'Actif').length;
        statPending.textContent = allSchools.filter(s => s.status === 'En attente').length;
        
        const uniqueCountries = new Set(allSchools.map(s => s.country));
        statCountries.textContent = uniqueCountries.size;
    }

    // --- Gestion Modal ---
    function openModal(id = null) {
        schoolForm.reset();
        document.getElementById('school-id').value = '';
        
        if (id) {
            modalTitle.textContent = "Éditer l'établissement";
            const school = dataService.getSchools().find(s => s.id == id);
            if (school) {
                document.getElementById('school-id').value = school.id;
                document.getElementById('school-name').value = school.name;
                document.getElementById('school-country').value = school.country;
                document.getElementById('school-city').value = school.city;
                document.getElementById('school-type').value = school.type;
                document.getElementById('school-status').value = school.status;
                document.getElementById('school-email').value = school.email || '';
                document.getElementById('school-phone').value = school.phone || '';
            }
        } else {
            modalTitle.textContent = "Ajouter un établissement";
        }
        
        modalOverlay.classList.add('active');
    }

    function closeModal() {
        modalOverlay.classList.remove('active');
    }

    btnAdd.addEventListener('click', () => openModal());
    btnCloseModal.addEventListener('click', closeModal);
    btnCancelModal.addEventListener('click', closeModal);

    // Fermer le modal si clic en dehors
    modalOverlay.addEventListener('click', (e) => {
        if (e.target === modalOverlay) closeModal();
    });

    // Sauvegarde (Ajout / Modification)
    schoolForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const id = document.getElementById('school-id').value;
        const schoolData = {
            name: document.getElementById('school-name').value,
            country: document.getElementById('school-country').value,
            city: document.getElementById('school-city').value,
            type: document.getElementById('school-type').value,
            status: document.getElementById('school-status').value,
            email: document.getElementById('school-email').value,
            phone: document.getElementById('school-phone').value,
            studentsCount: id ? undefined : 0 // Seulement à la création
        };

        if (id) {
            dataService.updateSchool(id, schoolData);
            showToast("Établissement mis à jour avec succès.");
        } else {
            dataService.addSchool(schoolData);
            showToast("Établissement ajouté avec succès.");
        }

        closeModal();
        initFilters();
        applyFilters();
        updateStats();
    });

    // --- Suppression ---
    function deleteSchool(id) {
        if (confirm("Êtes-vous sûr de vouloir supprimer cet établissement ? Cette action supprimera également les enseignants et étudiants associés.")) {
            dataService.deleteSchool(id);
            showToast("Établissement supprimé.");
            initFilters();
            applyFilters();
            updateStats();
        }
    }
    
    // --- Toasts ---
    function showToast(message) {
        const container = document.getElementById('toast-container');
        const toast = document.createElement('div');
        toast.className = 'toast show';
        toast.textContent = message;
        
        container.appendChild(toast);
        
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }
});
