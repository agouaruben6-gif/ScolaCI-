import 'package:flutter/material.dart';
import 'core/theme/app_theme.dart';
import 'features/auth/screens/splash_screen.dart';
import 'features/auth/screens/login_screen.dart';
import 'features/student/screens/student_dashboard.dart';
import 'features/teacher/screens/teacher_dashboard.dart';
import 'features/admin/screens/admin_dashboard.dart';

class ScolaCIApp extends StatelessWidget {
  const ScolaCIApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ScolaCI',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.darkTheme,
      initialRoute: '/',
      routes: {
        '/': (context) => SplashScreen(),
        '/login': (context) => LoginScreen(),
        '/student_dashboard': (context) => StudentDashboard(),
        '/teacher_dashboard': (context) => TeacherDashboard(),
        '/admin_dashboard': (context) => AdminDashboard(),
      },
    );
  }
}
