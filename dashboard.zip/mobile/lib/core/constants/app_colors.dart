import 'package:flutter/material.dart';

class AppColors {
  // Backgrounds
  static const Color background = Color(0xFF0A0E1A);
  
  // Glassmorphism
  static const Color glassCard = Color(0x0DFFFFFF); // rgba(255,255,255,0.05)
  static const Color glassBorder = Color(0x1AFFFFFF); // rgba(255,255,255,0.1)
  
  // Glows & Accents
  static const Color primaryGlow = Color(0xFF00D4FF); // Cyan/Teal
  static const Color secondaryGlow = Color(0xFFFF6B35); // Orange
  static const Color accent = Color(0xFF7B5EA7); // Purple
  
  // Border Glows
  static const Color borderGlow = Color(0x4D00D4FF); // rgba(0, 212, 255, 0.3)
  
  // Text
  static const Color textPrimary = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(0x99FFFFFF); // rgba(255,255,255,0.6)
  
  // Gradients
  static const LinearGradient glassGradient = LinearGradient(
    colors: [
      Color(0x1AFFFFFF),
      Color(0x00FFFFFF),
    ],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}
