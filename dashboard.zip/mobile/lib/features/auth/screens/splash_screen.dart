import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/widgets/gradient_background.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 3), () {
      Navigator.pushReplacementNamed(context, '/login');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GradientBackground(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.glassCard,
                  border: Border.all(color: AppColors.primaryGlow, width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.primaryGlow.withOpacity(0.5),
                      blurRadius: 30,
                      spreadRadius: 5,
                    ),
                  ],
                ),
                child: const Center(
                  child: Icon(
                    Icons.school_rounded,
                    size: 60,
                    color: AppColors.primaryGlow,
                  ),
                ),
              ).animate()
               .scale(duration: 800.ms, curve: Curves.easeOutBack)
               .shimmer(duration: 1200.ms, delay: 800.ms),
              const SizedBox(height: 30),
              Text(
                "ScolaCI",
                style: Theme.of(context).textTheme.displayMedium?.copyWith(
                  letterSpacing: 2,
                  shadows: [
                    BoxShadow(
                      color: AppColors.primaryGlow,
                      blurRadius: 10,
                    )
                  ],
                ),
              ).animate().fadeIn(delay: 500.ms).slideY(begin: 0.5),
            ],
          ),
        ),
      ),
    );
  }
}
