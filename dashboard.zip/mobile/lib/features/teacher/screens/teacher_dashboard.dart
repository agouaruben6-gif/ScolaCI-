import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/widgets/gradient_background.dart';
import '../../../core/widgets/glass_card.dart';
import '../../../core/widgets/bottom_nav_bar.dart';
import '../../../core/widgets/glow_button.dart';

class TeacherDashboard extends StatefulWidget {
  @override
  _TeacherDashboardState createState() => _TeacherDashboardState();
}

class _TeacherDashboardState extends State<TeacherDashboard> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: GradientBackground(
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              _buildHeader().animate().fadeIn().slideY(begin: -0.2),
              const SizedBox(height: 30),
              _buildQuickActionsGrid().animate().fadeIn(delay: 200.ms),
              const SizedBox(height: 30),
              _buildTodayClasses().animate().fadeIn(delay: 400.ms),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
      ).animate().fadeIn(delay: 600.ms).slideY(begin: 1.0),
    );
  }

  Widget _buildHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Welcome,",
              style: TextStyle(color: AppColors.textSecondary, fontSize: 16),
            ),
            Text(
              "Mr. Smith",
              style: Theme.of(context).textTheme.displaySmall?.copyWith(fontSize: 24),
            ),
          ],
        ),
        CircleAvatar(
          radius: 25,
          backgroundColor: AppColors.secondaryGlow.withOpacity(0.2),
          child: const Icon(Icons.person, color: AppColors.secondaryGlow),
        ),
      ],
    );
  }

  Widget _buildQuickActionsGrid() {
    return Row(
      children: [
        Expanded(
          child: GlassCard(
            height: 120,
            showGlow: true,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.fact_check_outlined, color: AppColors.primaryGlow, size: 30),
                const SizedBox(height: 8),
                Text(
                  "Take",
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 16),
                ),
                Text("Attendance", style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
              ],
            ),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: GlassCard(
            height: 120,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.grade_outlined, color: AppColors.accent, size: 30),
                const SizedBox(height: 8),
                Text(
                  "Enter",
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 16),
                ),
                Text("Grades", style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTodayClasses() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Today's Classes",
          style: Theme.of(context).textTheme.titleLarge,
        ),
        const SizedBox(height: 16),
        GlassCard(
          padding: EdgeInsets.zero,
          child: ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: 3,
            separatorBuilder: (context, index) => Divider(color: AppColors.glassBorder),
            itemBuilder: (context, index) {
              return ListTile(
                leading: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: AppColors.primaryGlow.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Center(
                    child: Text("08", style: TextStyle(color: AppColors.primaryGlow, fontWeight: FontWeight.bold)),
                  ),
                ),
                title: const Text("Mathematics - 10A", style: TextStyle(color: AppColors.textPrimary)),
                subtitle: const Text("Room 102 • 30 Students", style: TextStyle(color: AppColors.textSecondary)),
                trailing: ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryGlow.withOpacity(0.2),
                    foregroundColor: AppColors.primaryGlow,
                    elevation: 0,
                  ),
                  child: const Text("Start"),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
