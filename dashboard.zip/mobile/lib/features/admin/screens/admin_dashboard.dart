import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/widgets/gradient_background.dart';
import '../../../core/widgets/glass_card.dart';
import '../../../core/widgets/bottom_nav_bar.dart';

class AdminDashboard extends StatefulWidget {
  @override
  _AdminDashboardState createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: GradientBackground(
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              _buildHeader().animate().fadeIn().slideY(begin: -0.2),
              const SizedBox(height: 30),
              _buildStatsGrid().animate().fadeIn(delay: 200.ms),
              const SizedBox(height: 30),
              _buildActionGrid().animate().fadeIn(delay: 400.ms),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
      ).animate().fadeIn(delay: 600.ms).slideY(begin: 1.0),
    );
  }

  Widget _buildHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Administrator,",
              style: TextStyle(color: AppColors.textSecondary, fontSize: 16),
            ),
            Text(
              "ScolaCI Admin",
              style: Theme.of(context).textTheme.displaySmall?.copyWith(fontSize: 24),
            ),
          ],
        ),
        CircleAvatar(
          radius: 25,
          backgroundColor: AppColors.accent.withOpacity(0.2),
          child: const Icon(Icons.admin_panel_settings, color: AppColors.accent),
        ),
      ],
    );
  }

  Widget _buildStatsGrid() {
    return Row(
      children: [
        _buildStatCard("Students", "1,250", Icons.people_outline, AppColors.primaryGlow),
        const SizedBox(width: 12),
        _buildStatCard("Teachers", "45", Icons.school_outlined, AppColors.secondaryGlow),
        const SizedBox(width: 12),
        _buildStatCard("Classes", "32", Icons.class_outlined, AppColors.accent),
      ],
    );
  }

  Widget _buildStatCard(String title, String count, IconData icon, Color color) {
    return Expanded(
      child: GlassCard(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
        child: Column(
          children: [
            Icon(icon, color: color, size: 24),
            const SizedBox(height: 8),
            Text(count, style: Theme.of(context).textTheme.titleLarge),
            Text(title, style: TextStyle(color: AppColors.textSecondary, fontSize: 10)),
          ],
        ),
      ),
    );
  }

  Widget _buildActionGrid() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Quick Actions",
          style: Theme.of(context).textTheme.titleLarge,
        ),
        const SizedBox(height: 16),
        GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 2,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          childAspectRatio: 1.5,
          children: [
            _buildActionItem("Manage Users", Icons.manage_accounts, AppColors.primaryGlow),
            _buildActionItem("Announcements", Icons.campaign, AppColors.secondaryGlow),
            _buildActionItem("Schedules", Icons.calendar_month, AppColors.accent),
            _buildActionItem("Settings", Icons.settings, Colors.grey),
          ],
        ),
      ],
    );
  }

  Widget _buildActionItem(String title, IconData icon, Color color) {
    return GlassCard(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: color, size: 30),
          const SizedBox(height: 8),
          Text(title, style: const TextStyle(color: AppColors.textPrimary)),
        ],
      ),
    );
  }
}
