import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/widgets/gradient_background.dart';
import '../../../core/widgets/glass_card.dart';
import '../../../core/widgets/bottom_nav_bar.dart';

class StudentDashboard extends StatefulWidget {
  @override
  _StudentDashboardState createState() => _StudentDashboardState();
}

class _StudentDashboardState extends State<StudentDashboard> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: GradientBackground(
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              _buildHeader().animate().fadeIn().slideY(begin: -0.2),
              const SizedBox(height: 30),
              _buildStatsGrid().animate().fadeIn(delay: 200.ms),
              const SizedBox(height: 30),
              _buildSchedulePreview().animate().fadeIn(delay: 400.ms),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
      ).animate().fadeIn(delay: 600.ms).slideY(begin: 1.0),
    );
  }

  Widget _buildHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Good Morning,",
              style: TextStyle(color: AppColors.textSecondary, fontSize: 16),
            ),
            Text(
              "Alex Turner",
              style: Theme.of(context).textTheme.displaySmall?.copyWith(fontSize: 24),
            ),
          ],
        ),
        CircleAvatar(
          radius: 25,
          backgroundColor: AppColors.primaryGlow.withOpacity(0.2),
          child: const Icon(Icons.person, color: AppColors.primaryGlow),
        ),
      ],
    );
  }

  Widget _buildStatsGrid() {
    return Row(
      children: [
        Expanded(
          child: GlassCard(
            height: 120,
            showGlow: true,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.star_rounded, color: AppColors.secondaryGlow, size: 30),
                const SizedBox(height: 8),
                Text(
                  "16.5",
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 22),
                ),
                Text("Average", style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
              ],
            ),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: GlassCard(
            height: 120,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.check_circle_outline, color: AppColors.primaryGlow, size: 30),
                const SizedBox(height: 8),
                Text(
                  "98%",
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 22),
                ),
                Text("Attendance", style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSchedulePreview() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Today's Classes",
          style: Theme.of(context).textTheme.titleLarge,
        ),
        const SizedBox(height: 16),
        GlassCard(
          padding: EdgeInsets.zero,
          child: ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: 3,
            separatorBuilder: (context, index) => Divider(color: AppColors.glassBorder),
            itemBuilder: (context, index) {
              return ListTile(
                leading: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: AppColors.accent.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Center(
                    child: Text("08", style: TextStyle(color: AppColors.accent, fontWeight: FontWeight.bold)),
                  ),
                ),
                title: const Text("Mathematics", style: TextStyle(color: AppColors.textPrimary)),
                subtitle: const Text("Room 102 • Mr. Smith", style: TextStyle(color: AppColors.textSecondary)),
                trailing: const Icon(Icons.chevron_right, color: AppColors.textSecondary),
              );
            },
          ),
        ),
      ],
    );
  }
}
